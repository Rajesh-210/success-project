export const storeRef = {
  store: null,
  setStore(s) {
    this.store = s;
  },
  getState() {
    return this.store?.getState ? this.store.getState() : {};
  },
  dispatch(action) {
    return this.store?.dispatch ? this.store.dispatch(action) : null;
  }
};
