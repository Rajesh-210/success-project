import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../api/axiosClient';
import apiEndpoints from '../../api/apiEndpoints';

const TOKEN_KEY = import.meta.env.VITE_JWT_STORAGE_KEY || 'auth_token';

function saveToken(token) {
  if (token) localStorage.setItem(TOKEN_KEY, token);
}
function clearToken() {
  localStorage.removeItem(TOKEN_KEY);
}

function parseJwt(token) {
  try {
    const [, payload] = token.split('.');
    if (!payload) return null;
    const base64 = payload.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split('')
        .map(c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
        .join('')
    );
    return JSON.parse(jsonPayload);
  } catch {
    return null;
  }
}

function isTokenExpired(token) {
  const payload = parseJwt(token);
  if (!payload || !payload.exp) return false;
  const expiryMs = payload.exp * 1000;
  return Date.now() >= expiryMs;
}

function getInitialToken() {
  const stored = localStorage.getItem(TOKEN_KEY);
  if (!stored) return null;
  if (isTokenExpired(stored)) {
    clearToken();
    return null;
  }
  return stored;
}

const initialToken = getInitialToken();

export const register = createAsyncThunk(
  'auth/register',
  async (credentials, thunkAPI) => {
    try {
      const endpoint = apiEndpoints?.authentication?.registerUserPOST || '/api/auth/register';
      const { data } = await api.post(endpoint, credentials);
      return data;
    } catch (err) {
      return thunkAPI.rejectWithValue({
        message: err?.message || err?.response?.data?.message || 'Registration failed'
      });
    }
  }
);

export const login = createAsyncThunk(
  'auth/login',
  async (credentials, thunkAPI) => {
    try {
      const endpoint = apiEndpoints?.authentication?.loginPOST || '/api/auth/login';
      const { data } = await api.post(endpoint, credentials);
      return data;
    } catch (err) {
      return thunkAPI.rejectWithValue({
        message: err?.message || err?.response?.data?.message || 'Login failed'
      });
    }
  }
);

export const fetchProfile = createAsyncThunk(
  'auth/fetchProfile',
  async (_, thunkAPI) => {
    try {
      const endpoint = apiEndpoints?.users?.getCurrentUserProfileGET || '/api/users/me';
      const { data } = await api.get(endpoint);
      return data;
    } catch (err) {
      return thunkAPI.rejectWithValue({
        message: err?.message || err?.response?.data?.message || 'Failed to fetch profile'
      });
    }
  }
);

const initialState = {
  token: initialToken,
  user: null,
  status: 'idle',
  error: null,
  isAuthenticated: !!initialToken,
  sessionExpired: false
};

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    logout(state) {
      state.token = null;
      state.user = null;
      state.isAuthenticated = false;
      state.error = null;
      state.sessionExpired = false;
      clearToken();
    },
    setToken(state, action) {
      state.token = action.payload;
      state.isAuthenticated = !!action.payload;
      state.sessionExpired = false;
      saveToken(action.payload);
    },
    setSessionExpired(state, action) {
      state.sessionExpired = !!action.payload;
    }
  },
  extraReducers: builder => {
    builder
      .addCase(register.pending, state => {
        state.status = 'loading';
        state.error = null;
      })
      .addCase(register.fulfilled, (state, action) => {
        state.status = 'succeeded';
        const token = action.payload?.token || action.payload?.data?.token || null;
        state.token = token;
        state.isAuthenticated = !!token;
        if (token) saveToken(token);
        state.user = action.payload?.user || null;
      })
      .addCase(register.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload?.message || action.error?.message || 'Registration failed';
      })
      .addCase(login.pending, state => {
        state.status = 'loading';
        state.error = null;
      })
.addCase(login.fulfilled, (state, action) => {
        state.status = 'succeeded';
        const token = action.payload?.token || action.payload?.data?.token || null;
        state.token = token;
        state.isAuthenticated = !!token;
        if (token) saveToken(token);
        state.user = action.payload?.user || null;
        state.sessionExpired = false;
      })
      .addCase(login.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload?.message || action.error?.message || 'Login failed';
      })
      .addCase(fetchProfile.fulfilled, (state, action) => {
        state.user = action.payload?.user || action.payload || state.user;
      });
  }
});

export const { logout, setToken, setSessionExpired } = authSlice.actions;
export default authSlice.reducer;
