import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppShell } from '@/components/AppShell';
import { KPICard } from '@/components/KPICard';
import { IncidentTable } from '@/components/IncidentTable';
import { TimeSeriesChart } from '@/components/TimeSeriesChart';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertCircle, Radio, Camera, Activity } from 'lucide-react';
import api from '@/api/axiosClient';
import apiEndpoints from '@/api/apiEndpoints';
import { Button } from '@/components/ui/button';
import { useSelector, useDispatch } from 'react-redux';
import { logout } from '@/features/auth/authSlice';

export default function Dashboard() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { user, token } = useSelector((state) => state.auth);

  const [incidents, setIncidents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeIncidentsCount, setActiveIncidentsCount] = useState(0);
  const [onlineSensorsCount, setOnlineSensorsCount] = useState(0);
  const [onlineCamerasCount, setOnlineCamerasCount] = useState(0);
  const [systemHealthPercent, setSystemHealthPercent] = useState(0);
  const [incidentVolume, setIncidentVolume] = useState([]);
  const [sensorActivity, setSensorActivity] = useState([]);

  // Check if user is logged in
  useEffect(() => {
    const jwt = token || localStorage.getItem(import.meta.env.VITE_JWT_STORAGE_KEY || 'auth_token');
    if (!jwt) {
      navigate('/login');
    } else {
      loadDashboardData();
    }
  }, [token, navigate]);

  // Logout function
  const handleLogout = () => {
    dispatch(logout());
    navigate('/login');
  };

  const normalizeIncident = (inc) => {
    if (!inc) return null;
    return {
      id: String(inc.id),
      title: inc.title || inc.description || 'Untitled Incident',
      description: inc.description || '',
      status: (inc.status || 'active').toLowerCase(),
      severity: (inc.severity || 'medium').toLowerCase(),
      type: (inc.type || 'infrastructure').toLowerCase(),
      location: inc.location || { lat: 0, lng: 0, address: 'Unknown Location' },
      reportedAt: inc.reportedAt || new Date().toISOString(),
      resolvedAt: inc.resolvedAt || null,
      assignedTo: inc.assignedTo || null,
      tags: inc.tags || [],
    };
  };

  // Load incidents, dashboard stats, and analytics data from backend API
  const loadDashboardData = async () => {
    try {
      const incidentsUrl = apiEndpoints.incidents?.getAllIncidentsGET || '/api/incidents';
      const dashboardUrl =
        apiEndpoints.statistics?.getDashboardStatsGET || '/api/stats/dashboard';
      const incidentVolumeUrl =
        apiEndpoints.analytics?.getIncidentVolume24hGET ||
        '/api/analytics/incident-volume-24h';
      const sensorAlertsUrl =
        apiEndpoints.analytics?.getSensorAlerts24hGET ||
        '/api/analytics/sensor-alerts-24h';

      const [incRes, dashRes, volumeRes, alertsRes] = await Promise.all([
        api.get(incidentsUrl), // incidents can change often; no caching
        api.getCached(dashboardUrl),
        api.getCached(incidentVolumeUrl),
        api.getCached(sensorAlertsUrl),
      ]);

      // Recent incidents
      const incidentsPayload = Array.isArray(incRes.data?.data)
        ? incRes.data.data
        : Array.isArray(incRes.data)
          ? incRes.data
          : [];
      const normalized = incidentsPayload.map(normalizeIncident).filter(Boolean);
      const recentIncidents = normalized.slice(0, 5);
      setIncidents(recentIncidents);
      setActiveIncidentsCount(normalized.filter((i) => i.status === 'active').length);

      // Dashboard KPIs
      const stats = dashRes.data?.data || dashRes.data || {};
      setOnlineSensorsCount(stats.onlineSensors ?? 0);
      setOnlineCamerasCount(stats.onlineCameras ?? 0);
      setSystemHealthPercent(
        typeof stats.systemHealthPercent === 'number' ? stats.systemHealthPercent : 0
      );

      // Time series
      const volumePayload = Array.isArray(volumeRes.data?.data)
        ? volumeRes.data.data
        : Array.isArray(volumeRes.data)
          ? volumeRes.data
          : [];
      const alertsPayload = Array.isArray(alertsRes.data?.data)
        ? alertsRes.data.data
        : Array.isArray(alertsRes.data)
          ? alertsRes.data
          : [];

      setIncidentVolume(volumePayload);
      setSensorActivity(alertsPayload);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      setIncidents([]);
      setActiveIncidentsCount(0);
      setOnlineSensorsCount(0);
      setOnlineCamerasCount(0);
      setSystemHealthPercent(0);
      setIncidentVolume([]);
      setSensorActivity([]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AppShell>
      <div className="space-y-6">
        {/* Header with user info + logout */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Dashboard</h1>
            <p className="text-muted-foreground mt-1">
              Real-time overview of city operations
            </p>
          </div>

          {user && (
            <div className="flex items-center gap-4">
              <span className="text-sm text-muted-foreground">
                {user.name} ({user.role})
              </span>
              <Button variant="destructive" onClick={handleLogout}>
                Logout
              </Button>
            </div>
          )}
        </div>

        {/* KPI Cards */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <KPICard
            label="Active Incidents"
            value={activeIncidentsCount}
            change={-12}
            trend="down"
            icon={<AlertCircle className="h-5 w-5" />}
          />
          <KPICard
            label="Online Sensors"
            value={onlineSensorsCount}
            change={3}
            trend="up"
            icon={<Radio className="h-5 w-5" />}
          />
          <KPICard
            label="CCTV Cameras"
            value={onlineCamerasCount}
            change={0}
            trend="neutral"
            icon={<Camera className="h-5 w-5" />}
          />
          <KPICard
            label="System Health"
            value={`${systemHealthPercent.toFixed(1)}%`}
            change={0}
            trend="neutral"
            icon={<Activity className="h-5 w-5" />}
          />
        </div>

        {/* Charts */}
        <div className="grid gap-6 lg:grid-cols-2">
          <TimeSeriesChart
            title="Incident Trends (24h)"
            data={incidentVolume}
            color="#ef4444"
            yAxisLabel="Incidents"
          />
          <TimeSeriesChart
            title="Sensor Activity (24h)"
            data={sensorActivity}
            color="#3b82f6"
            yAxisLabel="Alerts"
          />
        </div>

        {/* Recent Incidents Table */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Incidents</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8 text-muted-foreground">
                Loading incidents...
              </div>
            ) : (
              <IncidentTable
                incidents={incidents}
                onRowClick={(incident) => navigate(`/incidents/${incident.id}`)}
              />
            )}
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}

