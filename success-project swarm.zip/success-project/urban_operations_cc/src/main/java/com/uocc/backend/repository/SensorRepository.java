package com.uocc.backend.repository;

import com.uocc.backend.entity.Sensor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface SensorRepository extends JpaRepository<Sensor, Long>, JpaSpecificationExecutor<Sensor> {
    
    @Query("SELECT COUNT(s) FROM Sensor s WHERE s.status = 'online'")
    long countOnlineSensors();
}
