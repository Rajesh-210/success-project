package com.uocc.backend.service;

import com.uocc.backend.dto.response.CountResponse;
import com.uocc.backend.dto.response.DashboardStatsResponse;
import com.uocc.backend.dto.response.IncidentSeverityCount;
import com.uocc.backend.dto.response.IncidentTypeCount;
import com.uocc.backend.dto.response.ResponseTimeByDay;
import com.uocc.backend.dto.response.TimeSeriesPoint;
import com.uocc.backend.entity.Incident;
import com.uocc.backend.entity.SensorReading;
import com.uocc.backend.repository.CameraRepository;
import com.uocc.backend.repository.IncidentRepository;
import com.uocc.backend.repository.SensorReadingRepository;
import com.uocc.backend.repository.SensorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class StatsService {

    private final IncidentRepository incidentRepository;
    private final SensorRepository sensorRepository;
    private final CameraRepository cameraRepository;
    private final SensorReadingRepository sensorReadingRepository;

    public CountResponse getActiveIncidentsCount() {
        long count = incidentRepository.countActiveIncidents();
        return new CountResponse(count);
    }

    public CountResponse getOnlineSensorsCount() {
        long count = sensorRepository.countOnlineSensors();
        return new CountResponse(count);
    }

    public CountResponse getOnlineCamerasCount() {
        long count = cameraRepository.countOnlineCameras();
        return new CountResponse(count);
    }

    public DashboardStatsResponse getDashboardStats() {
        long activeIncidents = incidentRepository.countActiveIncidents();
        long onlineSensors = sensorRepository.countOnlineSensors();
        long onlineCameras = cameraRepository.countOnlineCameras();

        long totalSensors = sensorRepository.count();
        long totalCameras = cameraRepository.count();
        long totalDevices = totalSensors + totalCameras;

        double systemHealthPercent = 100.0;
        if (totalDevices > 0) {
            systemHealthPercent = ((double) (onlineSensors + onlineCameras) / (double) totalDevices) * 100.0;
        }

        // For now, compute average resolution time (in minutes) for resolved incidents
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime sevenDaysAgo = now.minusDays(7);
        List<Incident> resolved = incidentRepository.findByResolvedAtIsNotNullAndResolvedAtBetween(sevenDaysAgo, now);
        double avgResponseMinutes = 0.0;
        if (!resolved.isEmpty()) {
            double totalMinutes = resolved.stream()
                    .filter(i -> i.getReportedAt() != null)
                    .mapToDouble(i -> ChronoUnit.MINUTES.between(i.getReportedAt(), i.getResolvedAt()))
                    .filter(m -> m >= 0)
                    .sum();
            long count = resolved.stream()
                    .filter(i -> i.getReportedAt() != null)
                    .filter(i -> ChronoUnit.MINUTES.between(i.getReportedAt(), i.getResolvedAt()) >= 0)
                    .count();
            if (count > 0) {
                avgResponseMinutes = totalMinutes / count;
            }
        }

        // Simple resolution rate: resolved incidents over total incidents in last 7 days
        long totalLast7Days = incidentRepository.countByReportedAtAfter(sevenDaysAgo);
        double resolutionRatePercent = 0.0;
        if (totalLast7Days > 0) {
            resolutionRatePercent = ((double) resolved.size() / (double) totalLast7Days) * 100.0;
        }

        // Performance score as a simple composite metric (0-10)
        double performanceScore = 0.0;
        if (avgResponseMinutes > 0) {
            double responseScore = Math.max(0.0, 10.0 - (avgResponseMinutes / 10.0));
            double healthScore = systemHealthPercent / 10.0;
            double resolutionScore = resolutionRatePercent / 10.0;
            performanceScore = (responseScore + healthScore + resolutionScore) / 3.0;
        }

        return DashboardStatsResponse.builder()
                .activeIncidents(activeIncidents)
                .onlineSensors(onlineSensors)
                .onlineCameras(onlineCameras)
                .systemHealthPercent(systemHealthPercent)
                .avgResponseTimeMinutes(avgResponseMinutes)
                .resolutionRatePercent(resolutionRatePercent)
                .performanceScore(performanceScore)
                .build();
    }

    public List<IncidentTypeCount> getIncidentsByType() {
        List<Object[]> results = incidentRepository.countByType();
        return results.stream()
                .map(row -> new IncidentTypeCount((String) row[0], (Long) row[1]))
                .collect(Collectors.toList());
    }

    public List<IncidentSeverityCount> getIncidentsBySeverity() {
        List<Object[]> results = incidentRepository.countBySeverity();
        return results.stream()
                .map(row -> new IncidentSeverityCount((String) row[0], (Long) row[1]))
                .collect(Collectors.toList());
    }

    public List<TimeSeriesPoint> getIncidentVolumeLast24Hours() {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime from = now.minusHours(24);

        List<Incident> incidents = incidentRepository.findByReportedAtBetween(from, now);

        Map<LocalDateTime, Long> buckets = new LinkedHashMap<>();
        for (int i = 0; i < 24; i++) {
            LocalDateTime bucketStart = from.plusHours(i).truncatedTo(ChronoUnit.HOURS);
            buckets.put(bucketStart, 0L);
        }

        for (Incident incident : incidents) {
            if (incident.getReportedAt() == null) continue;
            LocalDateTime bucket = incident.getReportedAt().truncatedTo(ChronoUnit.HOURS);
            if (bucket.isBefore(from)) {
                bucket = from.truncatedTo(ChronoUnit.HOURS);
            }
            if (bucket.isAfter(now)) {
                continue;
            }
            buckets.computeIfPresent(bucket, (k, v) -> v + 1);
        }

        return buckets.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .map(e -> new TimeSeriesPoint(e.getKey(), e.getValue()))
                .collect(Collectors.toList());
    }

    public List<TimeSeriesPoint> getSensorAlertsLast24Hours() {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime from = now.minusHours(24);

        List<SensorReading> readings = sensorReadingRepository.findByTimestampBetween(from, now);

        Map<LocalDateTime, Long> buckets = new LinkedHashMap<>();
        for (int i = 0; i < 24; i++) {
            LocalDateTime bucketStart = from.plusHours(i).truncatedTo(ChronoUnit.HOURS);
            buckets.put(bucketStart, 0L);
        }

        for (SensorReading reading : readings) {
            if (reading.getTimestamp() == null) continue;
            LocalDateTime bucket = reading.getTimestamp().truncatedTo(ChronoUnit.HOURS);
            if (bucket.isBefore(from)) {
                bucket = from.truncatedTo(ChronoUnit.HOURS);
            }
            if (bucket.isAfter(now)) {
                continue;
            }
            buckets.computeIfPresent(bucket, (k, v) -> v + 1);
        }

        return buckets.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .map(e -> new TimeSeriesPoint(e.getKey(), e.getValue()))
                .collect(Collectors.toList());
    }

    public List<ResponseTimeByDay> getResponseTimeByDayLast7Days() {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime from = now.minusDays(7);

        List<Incident> incidents = incidentRepository.findByResolvedAtIsNotNullAndResolvedAtBetween(from, now);

        Map<DayOfWeek, List<Long>> durationsByDay = new EnumMap<>(DayOfWeek.class);
        for (Incident incident : incidents) {
            if (incident.getReportedAt() == null || incident.getResolvedAt() == null) {
                continue;
            }
            long minutes = ChronoUnit.MINUTES.between(incident.getReportedAt(), incident.getResolvedAt());
            if (minutes < 0) {
                continue;
            }
            DayOfWeek dayOfWeek = incident.getResolvedAt().getDayOfWeek();
            durationsByDay.computeIfAbsent(dayOfWeek, d -> new ArrayList<>()).add(minutes);
        }

        List<ResponseTimeByDay> result = new ArrayList<>();
        for (DayOfWeek day : DayOfWeek.values()) {
            List<Long> durations = durationsByDay.get(day);
            if (durations == null || durations.isEmpty()) {
                continue;
            }
            double avg = durations.stream().mapToLong(Long::longValue).average().orElse(0.0);
            String label = day.getDisplayName(TextStyle.SHORT, Locale.ENGLISH);
            result.add(new ResponseTimeByDay(label, avg));
        }

        return result;
    }
}
