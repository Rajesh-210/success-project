package com.uocc.backend.controller;

import com.uocc.backend.dto.request.CameraCreateRequest;
import com.uocc.backend.dto.request.CameraUpdateRequest;
import com.uocc.backend.dto.response.CameraResponse;
import com.uocc.backend.service.CameraService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cameras")
@RequiredArgsConstructor
@SecurityRequirement(name = "bearerAuth")
@Tag(name = "Cameras", description = "CCTV camera management endpoints")
public class CameraController {

    private final CameraService cameraService;

    @GetMapping
    @Operation(summary = "Get all cameras")
    public ResponseEntity<List<CameraResponse>> getAllCameras(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) Integer limit,
            @RequestParam(required = false) Integer offset) {
        List<CameraResponse> cameras = cameraService.getAllCameras(status, limit, offset);
        return ResponseEntity.ok(cameras);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get camera by ID")
    public ResponseEntity<CameraResponse> getCameraById(@PathVariable Long id) {
        CameraResponse camera = cameraService.getCameraById(id);
        return ResponseEntity.ok(camera);
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'OPERATOR')")
    @Operation(summary = "Create a new camera")
    public ResponseEntity<CameraResponse> createCamera(@Valid @RequestBody CameraCreateRequest request) {
        CameraResponse camera = cameraService.createCamera(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(camera);
    }

    @PatchMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'OPERATOR')")
    @Operation(summary = "Update a camera")
    public ResponseEntity<CameraResponse> updateCamera(
            @PathVariable Long id,
            @Valid @RequestBody CameraUpdateRequest request) {
        CameraResponse camera = cameraService.updateCamera(id, request);
        return ResponseEntity.ok(camera);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Delete a camera (Admin only)")
    public ResponseEntity<Void> deleteCamera(@PathVariable Long id) {
        cameraService.deleteCamera(id);
        return ResponseEntity.ok().build();
    }
}
