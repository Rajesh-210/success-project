package com.uocc.backend.dto.response;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CameraResponse {
    private Long id;
    private String name;
    private JsonNode location;
    private String status;
    private String streamUrl;
    private String lastSnapshot;
    private Boolean recordingEnabled;
    private LocalDateTime lastUpdated;
}
