# Urban Operations Command Center (UOCC) - Backend API

Java Spring Boot REST API for the Urban Operations Command Center system.

## Project Overview

- **Framework**: Spring Boot 3.3.5
- **Java Version**: 17
- **Build Tool**: Maven
- **Database**: MySQL 8.0+
- **Authentication**: JWT (JSON Web Tokens) with 1-hour expiry
- **Password Hashing**: BCrypt
- **API Documentation**: Swagger/OpenAPI via springdoc-openapi
- **Database Migration**: Flyway

## Tech Stack

- Spring Boot Web
- Spring Data JPA
- Spring Security
- MySQL Connector
- Flyway Migration
- JWT (jjwt 0.12.3)
- Lombok
- MapStruct
- Hypersistence Utils (JSON support)
- Springdoc OpenAPI

## Prerequisites

1. **JDK 17** - Ensure Java 17 is installed and available on PATH
   ```powershell
   java -version
   ```

2. **Maven 3.9+** - Maven should be installed
   ```powershell
   mvn -version
   ```

3. **MySQL 8.0+** - MySQL server running on localhost:3306
   - Username: `root`
   - Password: `root`

## Database Setup

1. Start MySQL server (if not running)

2. Create the database:
   ```sql
CREATE DATABASE IF NOT EXISTS urban_db DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```

3. Verify database exists:
   ```sql
SHOW DATABASES LIKE 'urban_db';
   ```

From PowerShell:
```powershell
mysql -u root -proot -e "CREATE DATABASE IF NOT EXISTS urban_db DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
mysql -u root -proot -e "SHOW DATABASES LIKE 'urban_db';"
```

## Project Structure

```
backend/
├── src/
│   ├── main/
│   │   ├── java/com/uocc/backend/
│   │   │   ├── controller/          # REST controllers
│   │   │   ├── service/             # Business logic
│   │   │   │   └── impl/            # Service implementations
│   │   │   ├── dto/                 # Data Transfer Objects
│   │   │   │   ├── request/         # Request DTOs
│   │   │   │   └── response/        # Response DTOs
│   │   │   ├── entity/              # JPA entities
│   │   │   ├── repository/          # Spring Data repositories
│   │   │   ├── mapper/              # MapStruct mappers
│   │   │   ├── security/            # JWT & Security
│   │   │   ├── config/              # Configuration classes
│   │   │   ├── exception/           # Exception handlers
│   │   │   ├── util/                # Utility classes
│   │   │   └── BackendApplication.java
│   │   └── resources/
│   │       ├── db/migration/        # Flyway migrations
│   │       │   ├── V1__init_schema.sql
│   │       │   └── V2__seed_data.sql
│   │       └── application.yml
│   └── test/
├── docs/
│   └── openapi.yaml                 # OpenAPI specification
├── pom.xml
└── README.md
```

## Configuration

### JWT Secret (Optional)

Set environment variable for production:
```powershell
$env:JWT_SECRET="your-secret-key-min-256-bits"
```

Default secret in `application.yml`: `uocc-secret-key-please-change-in-production-min-256-bits`

### Application Properties

Key configurations in `application.yml`:
- Server port: `8080`
- Database URL: `jdbc:mysql://localhost:3306/urban_db?createDatabaseIfNotExist=true`
- JWT expiration: `60 minutes`
- Flyway: enabled with baseline on migrate

## Building the Application

From the `backend` directory:

```powershell
# Clean and package
mvn clean package

# Skip tests if needed
mvn clean package -DskipTests
```

## Running the Application

### Using Maven

```powershell
mvn spring-boot:run
```

### Using JAR

```powershell
java -jar target/backend-1.0.0.jar
```

## API Documentation

Once the application is running, access Swagger UI at:

```
http://localhost:8080/swagger-ui.html
```

OpenAPI JSON:
```
http://localhost:8080/v3/api-docs
```

## Default Users

The application seeds three users on first startup:

| Email | Password | Role |
|-------|----------|------|
| admin@uocc.com | Admin@123 | admin |
| operator@uocc.com | Operator@123 | operator |
| viewer@uocc.com | Viewer@123 | viewer |

**Note**: These passwords are stored as BCrypt hashes in the database.

## API Endpoints

### Authentication (`/api/auth`)
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login and get JWT token
- `GET /api/users/me` - Get current user profile

### Users (`/api/users`) - Admin only
- `GET /api/users` - List all users
- `GET /api/users/{id}` - Get user by ID
- `PATCH /api/users/{id}` - Update user
- `DELETE /api/users/{id}` - Delete user

### Incidents (`/api/incidents`)
- `GET /api/incidents` - List incidents (with filters)
- `GET /api/incidents/{id}` - Get incident by ID
- `POST /api/incidents` - Create incident (Admin/Operator)
- `PATCH /api/incidents/{id}` - Update incident (Admin/Operator)
- `DELETE /api/incidents/{id}` - Delete incident (Admin)

### Sensors (`/api/sensors`)
- `GET /api/sensors` - List sensors
- `GET /api/sensors/{id}` - Get sensor by ID
- `POST /api/sensors` - Create sensor (Admin/Operator)
- `PATCH /api/sensors/{id}` - Update sensor (Admin/Operator)
- `DELETE /api/sensors/{id}` - Delete sensor (Admin)

### Sensor Readings (`/api/sensors/{sensorId}/readings`)
- `GET /api/sensors/{sensorId}/readings` - Get readings for sensor
- `POST /api/sensors/{sensorId}/readings` - Add reading (Admin/Operator)

### Cameras (`/api/cameras`)
- `GET /api/cameras` - List cameras
- `GET /api/cameras/{id}` - Get camera by ID
- `POST /api/cameras` - Create camera (Admin/Operator)
- `PATCH /api/cameras/{id}` - Update camera (Admin/Operator)
- `DELETE /api/cameras/{id}` - Delete camera (Admin)

### Statistics (`/api/stats`)
- `GET /api/stats/active-incidents-count` - Count active incidents
- `GET /api/stats/online-sensors-count` - Count online sensors
- `GET /api/stats/online-cameras-count` - Count online cameras
- `GET /api/stats/dashboard` - Combined dashboard metrics

### Analytics (`/api/analytics`)
- `GET /api/analytics/incidents-by-type` - Incidents grouped by type
- `GET /api/analytics/incidents-by-severity` - Incidents grouped by severity

## Testing the API

### 1. Login to get JWT token

```powershell
$response = Invoke-RestMethod -Uri "http://localhost:8080/api/auth/login" `
    -Method POST `
    -ContentType "application/json" `
    -Body '{"email":"admin@uocc.com","password":"Admin@123"}'

$token = $response.token
```

### 2. Use token in subsequent requests

```powershell
$headers = @{
    "Authorization" = "Bearer $token"
    "Content-Type" = "application/json"
}

# Get incidents
Invoke-RestMethod -Uri "http://localhost:8080/api/incidents" `
    -Method GET `
    -Headers $headers
```

### 3. Create an incident

```powershell
$incident = @{
    title = "Test Incident"
    description = "This is a test"
    severity = "high"
    type = "infrastructure"
    location = @{
        lat = 40.7128
        lng = -74.0060
        address = "New York, NY"
    }
    assignedTo = "John Doe"
    tags = @("test", "infrastructure")
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://localhost:8080/api/incidents" `
    -Method POST `
    -Headers $headers `
    -Body $incident
```

## Query Parameters

### Pagination
- `limit` - Number of results per page (default: 20, max: 100)
- `offset` - Number of results to skip (default: 0)

### Sorting
- `sort` - Sort field and direction (e.g., `reportedAt,desc`)

### Filtering (Incidents)
- `status` - Filter by status (active, investigating, resolved, closed)
- `severity` - Filter by severity (low, medium, high, critical)
- `type` - Filter by type

### Filtering (Sensors)
- `status` - Filter by status (online, offline, maintenance)
- `type` - Filter by sensor type

Example:
```
GET /api/incidents?status=active&severity=high&limit=10&offset=0&sort=reportedAt,desc
```

## Roles and Permissions

### Admin
- Full CRUD access to all resources
- User management
- Can delete any resource

### Operator
- Create and update incidents, sensors, cameras, and readings
- Read access to all resources
- Cannot delete resources or manage users

### Viewer
- Read-only access to all non-admin resources
- Cannot create, update, or delete

## Database Schema

### Tables
- `users` - User accounts and authentication
- `incidents` - City incidents with JSON location and tags
- `sensors` - IoT sensors with JSON location and last_reading
- `sensor_readings` - Time-series sensor data
- `cameras` - CCTV cameras with JSON location

### JSON Columns
The following fields use MySQL JSON type:
- `incidents.location` - Geographic location
- `incidents.tags` - Array of tags
- `sensors.location` - Geographic location
- `sensors.last_reading` - Latest sensor reading
- `sensor_readings.metadata` - Reading metadata
- `cameras.location` - Geographic location

## Development

### Hot Reload
Spring Boot DevTools is not included. Restart the application to see changes.

### Logging
Log levels configured in `application.yml`:
- Application logs: DEBUG
- SQL logs: DEBUG
- Security logs: DEBUG

## Troubleshooting

### Cannot connect to MySQL
1. Verify MySQL is running: `mysql -u root -proot`
2. Check connection URL in `application.yml`
3. Ensure database `urban_db` exists

### Flyway migration fails
1. Check MySQL version (8.0+ required for JSON support)
2. Drop and recreate database if schema conflicts exist
3. Check Flyway migration files in `src/main/resources/db/migration`

### JWT token expired
Tokens expire after 1 hour. Login again to get a new token.

### Port 8080 already in use
Change port in `application.yml`:
```yaml
server:
  port: 8081
```

## Security Notes

1. **Change JWT Secret**: Use a strong secret key in production via `JWT_SECRET` environment variable
2. **Password Policy**: Minimum 8 characters, 1 uppercase, 1 digit
3. **HTTPS**: Use HTTPS in production (configure reverse proxy or Spring SSL)
4. **CORS**: Configure allowed origins in production
5. **Database**: Use dedicated MySQL user with limited privileges in production

## Next Steps

To complete the implementation, the following components need to be created:

1. **Response DTOs** - UserResponse, IncidentResponse, SensorResponse, etc.
2. **Request DTOs** - Complete set for all endpoints
3. **Services** - Business logic for each module
4. **Controllers** - REST endpoints for all 30 APIs
5. **Security Configuration** - JwtAuthenticationFilter, SecurityConfig
6. **Exception Handling** - GlobalExceptionHandler
7. **Mappers** - MapStruct interfaces
8. **Specifications** - JPA Specifications for filtering

## License

Proprietary - Urban Operations Command Center

## Contact

For questions or support, contact the development team.
