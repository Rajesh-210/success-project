// Auto-generated from backend/postman_collection.json. Do not edit manually.
/* eslint-disable */
export const apiEndpoints = {
  "authentication": {
    "registerUserPOST": "/api/auth/register",
    "loginPOST": "/api/auth/login"
  },
  "users": {
    "getCurrentUserProfileGET": "/api/users/me",
    "getAllUsersAdminGET": "/api/users",
    "getUserByIDAdminGET": "/api/users/1",
    "updateUserAdminPATCH": "/api/users/1",
    "deleteUserAdminDELETE": "/api/users/1"
  },
  "incidents": {
    "getAllIncidentsGET": "/api/incidents",
    "getIncidentByIDGET": "/api/incidents/1",
    "createIncidentPOST": "/api/incidents",
    "updateIncidentPATCH": "/api/incidents/1",
    "deleteIncidentAdminDELETE": "/api/incidents/1"
  },
  "sensors": {
    "getAllSensorsGET": "/api/sensors",
    "getSensorByIDGET": "/api/sensors/1",
    "createSensorPOST": "/api/sensors",
    "updateSensorPATCH": "/api/sensors/1",
    "deleteSensorAdminDELETE": "/api/sensors/1"
  },
  "sensorReadings": {
    "getSensorReadingsGET": "/api/sensors/1/readings",
    "addSensorReadingPOST": "/api/sensors/1/readings"
  },
  "cameras": {
    "getAllCamerasGET": "/api/cameras",
    "getCameraByIDGET": "/api/cameras/1",
    "createCameraPOST": "/api/cameras",
    "updateCameraPATCH": "/api/cameras/1",
    "deleteCameraAdminDELETE": "/api/cameras/1"
  },
  "statistics": {
    "getActiveIncidentsCountGET": "/api/stats/active-incidents-count",
    "getOnlineSensorsCountGET": "/api/stats/online-sensors-count",
    "getOnlineCamerasCountGET": "/api/stats/online-cameras-count",
    "getDashboardStatsGET": "/api/stats/dashboard"
  },
  "analytics": {
    "getIncidentsByTypeGET": "/api/analytics/incidents-by-type",
    "getIncidentsBySeverityGET": "/api/analytics/incidents-by-severity"
  }
};
export default apiEndpoints;
