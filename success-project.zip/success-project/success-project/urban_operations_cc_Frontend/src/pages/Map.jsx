import { useEffect, useState } from 'react';
import { AppShell } from '@/components/AppShell';
import { CityMap } from '@/components/CityMap';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import api from '@/api/axiosClient';
import apiEndpoints from '@/api/apiEndpoints';

export default function Map() {
  const [incidents, setIncidents] = useState([]);
  const [sensors, setSensors] = useState([]);
  const [cameras, setCameras] = useState([]);
  const [activeTab, setActiveTab] = useState('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadMapData();
  }, []);

  const normalizeIncident = (inc) => {
    if (!inc) return null;
    const rawLoc = inc.location || {};
    const lat = Number(rawLoc.lat ?? rawLoc.latitude) || 0;
    const lng = Number(rawLoc.lng ?? rawLoc.longitude) || 0;

    return {
      id: String(inc.id),
      location: { lat, lng },
      title: inc.title || inc.description || 'Incident',
      description: inc.description || '',
      severity: (inc.severity || 'medium').toLowerCase(),
      status: (inc.status || 'active').toLowerCase(),
    };
  };

  const normalizeSensor = (sensor) => {
    if (!sensor) return null;
    const rawLoc = sensor.location || {};
    const lat = Number(rawLoc.lat ?? rawLoc.latitude) || 0;
    const lng = Number(rawLoc.lng ?? rawLoc.longitude) || 0;

    return {
      id: String(sensor.id),
      location: { lat, lng },
      name: sensor.name || `Sensor ${sensor.id}`,
      type: (sensor.type || 'traffic').toLowerCase(),
      status: (sensor.status || 'online').toLowerCase(),
    };
  };

  const normalizeCamera = (cam) => {
    if (!cam) return null;
    const rawLoc = cam.location || {};
    const lat = Number(rawLoc.lat ?? rawLoc.latitude) || 0;
    const lng = Number(rawLoc.lng ?? rawLoc.longitude) || 0;

    return {
      id: String(cam.id),
      location: { lat, lng },
      name: cam.name || `Camera ${cam.id}`,
      status: (cam.status || 'offline').toLowerCase(),
    };
  };

  const loadMapData = async () => {
    setLoading(true);
    try {
      const incidentsUrl = apiEndpoints.incidents?.getAllIncidentsGET || '/api/incidents';
      const sensorsUrl = apiEndpoints.sensors?.getAllSensorsGET || '/api/sensors';
      const camerasUrl = apiEndpoints.cameras?.getAllCamerasGET || '/api/cameras';

      const [incRes, sensorRes, camRes] = await Promise.all([
        api.getCached(incidentsUrl),
        api.getCached(sensorsUrl),
        api.getCached(camerasUrl),
      ]);

      const incPayload = Array.isArray(incRes.data?.data)
        ? incRes.data.data
        : Array.isArray(incRes.data)
          ? incRes.data
          : [];
      const sensorPayload = Array.isArray(sensorRes.data?.data)
        ? sensorRes.data.data
        : Array.isArray(sensorRes.data)
          ? sensorRes.data
          : [];
      const camPayload = Array.isArray(camRes.data?.data)
        ? camRes.data.data
        : Array.isArray(camRes.data)
          ? camRes.data
          : [];

      const incList = incPayload.map(normalizeIncident).filter(Boolean);
      const sensorList = sensorPayload.map(normalizeSensor).filter(Boolean);
      const camList = camPayload.map(normalizeCamera).filter(Boolean);

      setIncidents(incList);
      setSensors(sensorList);
      setCameras(camList);
    } catch (error) {
      console.error('Error loading map data:', error);
      setIncidents([]);
      setSensors([]);
      setCameras([]);
    } finally {
      setLoading(false);
    }
  };

  const getMapMarkers = () => {
    if (activeTab === 'incidents') {
      return incidents.map((inc) => ({
        id: inc.id,
        position: [inc.location.lat, inc.location.lng],
        title: inc.title,
        description: inc.description,
        type: 'incident',
        status: inc.severity,
      }));
    }

    if (activeTab === 'sensors') {
      return sensors.map((sensor) => ({
        id: sensor.id,
        position: [sensor.location.lat, sensor.location.lng],
        title: sensor.name,
        description: `${sensor.type} sensor`,
        type: 'sensor',
        status: sensor.status,
      }));
    }

    if (activeTab === 'cameras') {
      return cameras.map((cam) => ({
        id: cam.id,
        position: [cam.location.lat, cam.location.lng],
        title: cam.name,
        description: 'CCTV Camera',
        type: 'camera',
        status: cam.status,
      }));
    }

    // 'all' tab: combine all
    return [
      ...incidents.map((inc) => ({
        id: `incident-${inc.id}`,
        position: [inc.location.lat, inc.location.lng],
        title: inc.title,
        description: inc.description,
        type: 'incident',
        status: inc.severity,
      })),
      ...sensors.map((sensor) => ({
        id: `sensor-${sensor.id}`,
        position: [sensor.location.lat, sensor.location.lng],
        title: sensor.name,
        description: `${sensor.type} sensor`,
        type: 'sensor',
        status: sensor.status,
      })),
      ...cameras.map((cam) => ({
        id: `camera-${cam.id}`,
        position: [cam.location.lat, cam.location.lng],
        title: cam.name,
        description: 'CCTV Camera',
        type: 'camera',
        status: cam.status,
      })),
    ];
  };

  const getMapCenter = () => {
    let items = [];

    if (activeTab === 'incidents') {
      items = incidents;
    } else if (activeTab === 'sensors') {
      items = sensors;
    } else if (activeTab === 'cameras') {
      items = cameras;
    } else {
      // 'all' tab: use all visible items
      items = [...incidents, ...sensors, ...cameras];
    }

    if (items.length === 0) {
      // Fallback center (e.g., city center) when no data is available
      return [40.7128, -74.006];
    }

    const sum = items.reduce(
      (acc, item) => {
        const lat = item.location?.lat ?? 0;
        const lng = item.location?.lng ?? 0;
        return {
          lat: acc.lat + lat,
          lng: acc.lng + lng,
          count: acc.count + 1,
        };
      },
      { lat: 0, lng: 0, count: 0 }
    );

    if (sum.count === 0) {
      return [40.7128, -74.006];
    }

    return [sum.lat / sum.count, sum.lng / sum.count];
  };

  return (
    <AppShell>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">City Map</h1>
          <p className="text-muted-foreground mt-1">
            Real-time geospatial view of city infrastructure
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="incidents">
              Incidents
              <Badge variant="secondary" className="ml-2">
                {incidents.length}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="sensors">
              Sensors
              <Badge variant="secondary" className="ml-2">
                {sensors.length}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="cameras">
              Cameras
              <Badge variant="secondary" className="ml-2">
                {cameras.length}
              </Badge>
            </TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab} className="mt-6">
            {loading ? (
              <Card>
                <CardContent className="flex h-[200px] items-center justify-center text-muted-foreground">
                  Loading map data...
                </CardContent>
              </Card>
            ) : (
              <CityMap markers={getMapMarkers()} center={getMapCenter()} zoom={12} />
            )}
          </TabsContent>
        </Tabs>

        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Active Incidents</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{incidents.length}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Showing on map
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Online Sensors</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{sensors.length}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Actively monitoring
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Active Cameras</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{cameras.length}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Live streaming
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppShell>
  );
}

