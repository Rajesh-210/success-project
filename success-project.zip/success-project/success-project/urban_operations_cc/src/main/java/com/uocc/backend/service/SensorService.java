package com.uocc.backend.service;

import com.uocc.backend.dto.request.SensorCreateRequest;
import com.uocc.backend.dto.request.SensorReadingCreateRequest;
import com.uocc.backend.dto.request.SensorUpdateRequest;
import com.uocc.backend.dto.response.SensorReadingResponse;
import com.uocc.backend.dto.response.SensorResponse;
import com.uocc.backend.entity.Sensor;
import com.uocc.backend.entity.SensorReading;
import com.uocc.backend.exception.ResourceNotFoundException;
import com.uocc.backend.repository.SensorReadingRepository;
import com.uocc.backend.repository.SensorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class SensorService {

    private final SensorRepository sensorRepository;
    private final SensorReadingRepository sensorReadingRepository;

    @Transactional
    public SensorResponse createSensor(SensorCreateRequest request) {
        Sensor sensor = Sensor.builder()
                .name(request.getName())
                .type(request.getType())
                .status(request.getStatus())
                .location(request.getLocation())
                .lastReading(request.getLastReading())
                .build();

        sensor = sensorRepository.save(sensor);
        return mapToResponse(sensor);
    }

    public List<SensorResponse> getAllSensors(String status, String type, Integer limit, Integer offset) {
        Specification<Sensor> spec = Specification.where(null);

        if (status != null && !status.isEmpty()) {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("status"), status));
        }
        if (type != null && !type.isEmpty()) {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("type"), type));
        }

        int pageSize = (limit != null && limit > 0 && limit <= 100) ? limit : 20;
        int pageOffset = (offset != null && offset >= 0) ? offset : 0;
        Pageable pageable = PageRequest.of(pageOffset / pageSize, pageSize, Sort.by("id").descending());

        return sensorRepository.findAll(spec, pageable).getContent().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public SensorResponse getSensorById(Long id) {
        Sensor sensor = sensorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Sensor not found with id: " + id));
        return mapToResponse(sensor);
    }

    @Transactional
    public SensorResponse updateSensor(Long id, SensorUpdateRequest request) {
        Sensor sensor = sensorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Sensor not found with id: " + id));

        if (request.getName() != null) sensor.setName(request.getName());
        if (request.getType() != null) sensor.setType(request.getType());
        if (request.getStatus() != null) sensor.setStatus(request.getStatus());
        if (request.getLocation() != null) sensor.setLocation(request.getLocation());
        if (request.getLastReading() != null) sensor.setLastReading(request.getLastReading());

        sensor = sensorRepository.save(sensor);
        return mapToResponse(sensor);
    }

    @Transactional
    public void deleteSensor(Long id) {
        if (!sensorRepository.existsById(id)) {
            throw new ResourceNotFoundException("Sensor not found with id: " + id);
        }
        sensorRepository.deleteById(id);
    }

    public List<SensorReadingResponse> getSensorReadings(Long sensorId, Integer limit) {
        Sensor sensor = sensorRepository.findById(sensorId)
                .orElseThrow(() -> new ResourceNotFoundException("Sensor not found with id: " + sensorId));

        List<SensorReading> readings = sensorReadingRepository.findBySensorIdOrderByTimestampDesc(sensorId);
        int resultLimit = (limit != null && limit > 0) ? limit : 50;
        
        return readings.stream()
                .limit(resultLimit)
                .map(this::mapReadingToResponse)
                .collect(Collectors.toList());
    }

    @Transactional
    public SensorReadingResponse addSensorReading(Long sensorId, SensorReadingCreateRequest request) {
        Sensor sensor = sensorRepository.findById(sensorId)
                .orElseThrow(() -> new ResourceNotFoundException("Sensor not found with id: " + sensorId));

        SensorReading reading = SensorReading.builder()
                .sensor(sensor)
                .value(request.getValue())
                .timestamp(request.getTimestamp())
                .metadata(request.getMetadata())
                .build();

        reading = sensorReadingRepository.save(reading);
        return mapReadingToResponse(reading);
    }

    private SensorResponse mapToResponse(Sensor sensor) {
        return SensorResponse.builder()
                .id(sensor.getId())
                .name(sensor.getName())
                .type(sensor.getType())
                .status(sensor.getStatus())
                .location(sensor.getLocation())
                .lastReading(sensor.getLastReading())
                .build();
    }

    private SensorReadingResponse mapReadingToResponse(SensorReading reading) {
        return SensorReadingResponse.builder()
                .id(reading.getId())
                .sensorId(reading.getSensor().getId())
                .value(reading.getValue())
                .timestamp(reading.getTimestamp())
                .metadata(reading.getMetadata())
                .build();
    }
}
