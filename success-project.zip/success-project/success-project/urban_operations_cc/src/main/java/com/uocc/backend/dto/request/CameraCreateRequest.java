package com.uocc.backend.dto.request;

import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CameraCreateRequest {

    @NotBlank(message = "Name is required")
    private String name;

    private JsonNode location;

    @NotBlank(message = "Status is required")
    @Pattern(regexp = "^(online|offline|maintenance)$", message = "Status must be online, offline, or maintenance")
    private String status;

    private String streamUrl;
    
    private Boolean recordingEnabled;
}
