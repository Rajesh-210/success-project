package com.uocc.backend.dto.request;

import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SensorReadingCreateRequest {

    @NotNull(message = "Value is required")
    private BigDecimal value;

    @NotNull(message = "Timestamp is required")
    private LocalDateTime timestamp;

    private JsonNode metadata;
}
