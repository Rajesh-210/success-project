package com.uocc.backend.repository;

import com.uocc.backend.entity.Incident;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface IncidentRepository extends JpaRepository<Incident, Long>, JpaSpecificationExecutor<Incident> {
    
    @Query("SELECT COUNT(i) FROM Incident i WHERE i.status = 'active'")
    long countActiveIncidents();
    
    @Query("SELECT i.type as type, COUNT(i) as count FROM Incident i GROUP BY i.type")
    java.util.List<Object[]> countByType();
    
    @Query("SELECT i.severity as severity, COUNT(i) as count FROM Incident i GROUP BY i.severity")
    java.util.List<Object[]> countBySeverity();

    java.util.List<Incident> findByReportedAtBetween(java.time.LocalDateTime from, java.time.LocalDateTime to);

    java.util.List<Incident> findByResolvedAtIsNotNullAndResolvedAtBetween(java.time.LocalDateTime from, java.time.LocalDateTime to);

    long countByReportedAtAfter(java.time.LocalDateTime from);
}
