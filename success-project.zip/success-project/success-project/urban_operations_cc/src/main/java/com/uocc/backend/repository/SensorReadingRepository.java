package com.uocc.backend.repository;

import com.uocc.backend.entity.SensorReading;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface SensorReadingRepository extends JpaRepository<SensorReading, Long>, JpaSpecificationExecutor<SensorReading> {
    
    List<SensorReading> findBySensorIdOrderByTimestampDesc(Long sensorId);
    
    List<SensorReading> findBySensorIdAndTimestampBetweenOrderByTimestampDesc(
        Long sensorId, LocalDateTime from, LocalDateTime to);

    List<SensorReading> findByTimestampBetween(LocalDateTime from, LocalDateTime to);
}
