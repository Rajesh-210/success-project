package com.uocc.backend.dto.request;

import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IncidentUpdateRequest {

    @Size(min = 5, max = 200, message = "Title must be between 5 and 200 characters")
    private String title;

    private String description;

    @Pattern(regexp = "^(active|investigating|resolved|closed)$", message = "Status must be active, investigating, resolved, or closed")
    private String status;

    @Pattern(regexp = "^(low|medium|high|critical)$", message = "Severity must be low, medium, high, or critical")
    private String severity;

    private String type;

    private JsonNode location;
    
    private LocalDateTime resolvedAt;
    
    private String assignedTo;
    
    private JsonNode tags;
}
