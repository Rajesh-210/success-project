package com.uocc.backend.dto.request;

import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SensorUpdateRequest {

    private String name;

    @Pattern(regexp = "^(air_quality|traffic|noise|water|weather)$", message = "Type must be air_quality, traffic, noise, water, or weather")
    private String type;

    @Pattern(regexp = "^(online|offline|maintenance)$", message = "Status must be online, offline, or maintenance")
    private String status;

    private JsonNode location;
    
    private JsonNode lastReading;
}
