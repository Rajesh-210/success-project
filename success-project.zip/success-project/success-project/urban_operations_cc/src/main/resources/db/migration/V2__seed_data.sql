-- Seed core users for UOCC demo
-- Password hash below should correspond to a known password such as Admin@123
-- All demo users share the same hash for simplicity

INSERT INTO users (name, email, password, role, avatar)
VALUES
  ('Admin User', 'admin@uocc.com', '$2a$10$9K8VxJ8zzXzfqVu8M2xh3eZ3yf3bvbXz3JxF.xGQxWxFxH6xJ5xKm', 'admin', NULL),
  ('Primary Operator', 'operator@uocc.com', '$2a$10$9K8VxJ8zzXzfqVu8M2xh3eZ3yf3bvbXz3JxF.xGQxWxFxH6xJ5xKm', 'operator', NULL),
  ('Primary Viewer', 'viewer@uocc.com', '$2a$10$9K8VxJ8zzXzfqVu8M2xh3eZ3yf3bvbXz3JxF.xGQxWxFxH6xJ5xKm', 'viewer', NULL);


-- Seed sensors used by the frontend (5-8 records, all key types covered)
INSERT INTO sensors (name, type, status, location, last_reading)
VALUES
  ('AQ-101', 'air_quality', 'online',
    JSON_OBJECT('lat', 18.5204, 'lng', 73.8567, 'address', 'City Center Air Station'),
    JSON_OBJECT('value', 85, 'unit', 'AQI', 'timestamp', NOW())
  ),
  ('AQ-102', 'air_quality', 'offline',
    JSON_OBJECT('lat', 18.5304, 'lng', 73.8667, 'address', 'Industrial Air Station'),
    JSON_OBJECT('value', 0, 'unit', 'AQI', 'timestamp', NOW())
  ),
  ('TF-201', 'traffic', 'online',
    JSON_OBJECT('lat', 18.5210, 'lng', 73.8570, 'address', 'Main Junction Traffic Cam'),
    JSON_OBJECT('value', 120, 'unit', 'veh/min', 'timestamp', NOW())
  ),
  ('TF-202', 'traffic', 'maintenance',
    JSON_OBJECT('lat', 18.5225, 'lng', 73.8590, 'address', 'East Bypass Junction'),
    JSON_OBJECT('value', 0, 'unit', 'veh/min', 'timestamp', NOW())
  ),
  ('NS-301', 'noise', 'online',
    JSON_OBJECT('lat', 18.5195, 'lng', 73.8555, 'address', 'Commercial Market Noise Monitor'),
    JSON_OBJECT('value', 72, 'unit', 'dB', 'timestamp', NOW())
  ),
  ('WT-401', 'water', 'online',
    JSON_OBJECT('lat', 18.5185, 'lng', 73.8545, 'address', 'Riverside Water Station'),
    JSON_OBJECT('value', 6.5, 'unit', 'pH', 'timestamp', NOW())
  ),
  ('WE-501', 'weather', 'online',
    JSON_OBJECT('lat', 18.5220, 'lng', 73.8580, 'address', 'City Weather Station'),
    JSON_OBJECT('value', 29.5, 'unit', 'C', 'timestamp', NOW())
  ),
  ('NS-302', 'noise', 'maintenance',
    JSON_OBJECT('lat', 18.5175, 'lng', 73.8535, 'address', 'Residential Block Noise Monitor'),
    JSON_OBJECT('value', 0, 'unit', 'dB', 'timestamp', NOW())
  );


-- Seed cameras used by the CCTV & dashboard views (8 cameras)
INSERT INTO cameras (name, location, status, stream_url, recording_enabled)
VALUES
  ('CAM-01',
    JSON_OBJECT('lat', 18.5204, 'lng', 73.8567, 'address', 'City Square'),
    'online', 'rtsp://stream.uocc.local/cam01', TRUE
  ),
  ('CAM-02',
    JSON_OBJECT('lat', 18.5210, 'lng', 73.8575, 'address', 'Bus Terminal'),
    'online', 'rtsp://stream.uocc.local/cam02', TRUE
  ),
  ('CAM-03',
    JSON_OBJECT('lat', 18.5195, 'lng', 73.8550, 'address', 'Riverside Bridge'),
    'maintenance', 'rtsp://stream.uocc.local/cam03', FALSE
  ),
  ('CAM-04',
    JSON_OBJECT('lat', 18.5230, 'lng', 73.8600, 'address', 'Industrial Gate'),
    'online', 'rtsp://stream.uocc.local/cam04', TRUE
  ),
  ('CAM-05',
    JSON_OBJECT('lat', 18.5170, 'lng', 73.8520, 'address', 'Residential Crossroad'),
    'offline', 'rtsp://stream.uocc.local/cam05', FALSE
  ),
  ('CAM-06',
    JSON_OBJECT('lat', 18.5240, 'lng', 73.8610, 'address', 'Logistics Hub'),
    'online', 'rtsp://stream.uocc.local/cam06', TRUE
  ),
  ('CAM-07',
    JSON_OBJECT('lat', 18.5260, 'lng', 73.8630, 'address', 'Ring Road North'),
    'online', 'rtsp://stream.uocc.local/cam07', TRUE
  ),
  ('CAM-08',
    JSON_OBJECT('lat', 18.5160, 'lng', 73.8510, 'address', 'Park Entrance'),
    'maintenance', 'rtsp://stream.uocc.local/cam08', FALSE
  );


-- Seed incidents to drive lists, map, alerts, and analytics (10 incidents)
INSERT INTO incidents (title, description, status, severity, type, location, reported_at, resolved_at, assigned_to, tags)
VALUES
  (
    'Traffic congestion at City Square',
    'Heavy traffic and long queues reported at City Square intersection.',
    'active',
    'high',
    'traffic',
    JSON_OBJECT('lat', 18.5204, 'lng', 73.8567, 'address', 'City Square'),
    DATE_SUB(NOW(), INTERVAL 2 HOUR),
    NULL,
    'Traffic Control Team',
    JSON_ARRAY('traffic', 'congestion', 'urgent')
  ),
  (
    'Water leakage near Riverside',
    'Continuous water leakage reported near Riverside pump station.',
    'investigating',
    'medium',
    'infrastructure',
    JSON_OBJECT('lat', 18.5185, 'lng', 73.8545, 'address', 'Riverside Pump Station'),
    DATE_SUB(NOW(), INTERVAL 5 HOUR),
    NULL,
    'Water Department',
    JSON_ARRAY('water', 'leak')
  ),
  (
    'Air quality alert in Market Area',
    'High PM2.5 levels detected in the central market area.',
    'active',
    'critical',
    'environment',
    JSON_OBJECT('lat', 18.5195, 'lng', 73.8555, 'address', 'Central Market'),
    DATE_SUB(NOW(), INTERVAL 1 HOUR),
    NULL,
    'Environmental Team',
    JSON_ARRAY('air', 'pollution', 'alert')
  ),
  (
    'Noise complaint near Bus Terminal',
    'Residents reporting loud noise from late-night loading at the bus terminal.',
    'active',
    'low',
    'environment',
    JSON_OBJECT('lat', 18.5210, 'lng', 73.8575, 'address', 'Bus Terminal'),
    DATE_SUB(NOW(), INTERVAL 10 HOUR),
    NULL,
    'City Operations',
    JSON_ARRAY('noise', 'complaint')
  ),
  (
    'Transformer fire near Industrial Zone',
    'Small fire reported near transformer in industrial zone, now contained.',
    'resolved',
    'critical',
    'infrastructure',
    JSON_OBJECT('lat', 18.5250, 'lng', 73.8600, 'address', 'Industrial Zone Substation'),
    DATE_SUB(NOW(), INTERVAL 30 HOUR),
    DATE_SUB(NOW(), INTERVAL 26 HOUR),
    'Fire Department',
    JSON_ARRAY('fire', 'power', 'safety')
  ),
  (
    'Signal failure at Ring Road North',
    'Traffic signal stuck on red, causing backups.',
    'investigating',
    'high',
    'infrastructure',
    JSON_OBJECT('lat', 18.5260, 'lng', 73.8630, 'address', 'Ring Road North'),
    DATE_SUB(NOW(), INTERVAL 20 HOUR),
    NULL,
    'Traffic Control Team',
    JSON_ARRAY('signal', 'traffic')
  ),
  (
    'Flooding near Riverside Park',
    'Rising water levels in park underpass.',
    'active',
    'high',
    'environment',
    JSON_OBJECT('lat', 18.5170, 'lng', 73.8520, 'address', 'Riverside Park Underpass'),
    DATE_SUB(NOW(), INTERVAL 8 HOUR),
    NULL,
    'Disaster Management',
    JSON_ARRAY('flood', 'park')
  ),
  (
    'CCTV offline at Logistics Hub',
    'Primary logistics hub camera offline.',
    'active',
    'medium',
    'security',
    JSON_OBJECT('lat', 18.5240, 'lng', 73.8610, 'address', 'Logistics Hub'),
    DATE_SUB(NOW(), INTERVAL 3 HOUR),
    NULL,
    'Security Team',
    JSON_ARRAY('cctv', 'offline')
  ),
  (
    'Gas leak reported near Industrial Gate',
    'Suspected gas leak in industrial entry road.',
    'active',
    'critical',
    'security',
    JSON_OBJECT('lat', 18.5230, 'lng', 73.8600, 'address', 'Industrial Gate'),
    DATE_SUB(NOW(), INTERVAL 4 HOUR),
    NULL,
    'Emergency Response',
    JSON_ARRAY('gas', 'leak', 'evacuate')
  ),
  (
    'Fallen tree at Park Entrance',
    'Tree fallen blocking vehicle entry.',
    'resolved',
    'low',
    'environment',
    JSON_OBJECT('lat', 18.5160, 'lng', 73.8510, 'address', 'Central Park Entrance'),
    DATE_SUB(NOW(), INTERVAL 48 HOUR),
    DATE_SUB(NOW(), INTERVAL 42 HOUR),
    'Parks Department',
    JSON_ARRAY('tree', 'blockage')
  );


-- Seed sensor readings for first 3 sensors (5 readings each) for 24h time-series
INSERT INTO sensor_readings (sensor_id, value, `timestamp`, metadata)
SELECT s.id, v.val, DATE_SUB(NOW(), INTERVAL v.h HOUR),
       JSON_OBJECT('source','auto','seq',v.h)
FROM sensors s
JOIN (
  SELECT 0 AS h, 75.0 AS val UNION ALL
  SELECT 1, 76.5 UNION ALL
  SELECT 2, 78.2 UNION ALL
  SELECT 3, 80.1 UNION ALL
  SELECT 4, 79.0
) v
JOIN (SELECT id FROM sensors ORDER BY id LIMIT 3) s3 ON s.id = s3.id;
