package com.uocc.backend.service;

import com.uocc.backend.dto.request.CameraCreateRequest;
import com.uocc.backend.dto.request.CameraUpdateRequest;
import com.uocc.backend.dto.response.CameraResponse;
import com.uocc.backend.entity.Camera;
import com.uocc.backend.exception.ResourceNotFoundException;
import com.uocc.backend.repository.CameraRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CameraService {

    private final CameraRepository cameraRepository;

    @Transactional
    public CameraResponse createCamera(CameraCreateRequest request) {
        Camera camera = Camera.builder()
                .name(request.getName())
                .location(request.getLocation())
                .status(request.getStatus())
                .streamUrl(request.getStreamUrl())
                .recordingEnabled(request.getRecordingEnabled() != null ? request.getRecordingEnabled() : true)
                .build();

        camera = cameraRepository.save(camera);
        return mapToResponse(camera);
    }

    public List<CameraResponse> getAllCameras(String status, Integer limit, Integer offset) {
        Specification<Camera> spec = Specification.where(null);

        if (status != null && !status.isEmpty()) {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("status"), status));
        }

        int pageSize = (limit != null && limit > 0 && limit <= 100) ? limit : 20;
        int pageOffset = (offset != null && offset >= 0) ? offset : 0;
        Pageable pageable = PageRequest.of(pageOffset / pageSize, pageSize, Sort.by("id").descending());

        return cameraRepository.findAll(spec, pageable).getContent().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public CameraResponse getCameraById(Long id) {
        Camera camera = cameraRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Camera not found with id: " + id));
        return mapToResponse(camera);
    }

    @Transactional
    public CameraResponse updateCamera(Long id, CameraUpdateRequest request) {
        Camera camera = cameraRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Camera not found with id: " + id));

        if (request.getName() != null) camera.setName(request.getName());
        if (request.getLocation() != null) camera.setLocation(request.getLocation());
        if (request.getStatus() != null) camera.setStatus(request.getStatus());
        if (request.getStreamUrl() != null) camera.setStreamUrl(request.getStreamUrl());
        if (request.getLastSnapshot() != null) camera.setLastSnapshot(request.getLastSnapshot());
        if (request.getRecordingEnabled() != null) camera.setRecordingEnabled(request.getRecordingEnabled());

        camera = cameraRepository.save(camera);
        return mapToResponse(camera);
    }

    @Transactional
    public void deleteCamera(Long id) {
        if (!cameraRepository.existsById(id)) {
            throw new ResourceNotFoundException("Camera not found with id: " + id);
        }
        cameraRepository.deleteById(id);
    }

    private CameraResponse mapToResponse(Camera camera) {
        return CameraResponse.builder()
                .id(camera.getId())
                .name(camera.getName())
                .location(camera.getLocation())
                .status(camera.getStatus())
                .streamUrl(camera.getStreamUrl())
                .lastSnapshot(camera.getLastSnapshot())
                .recordingEnabled(camera.getRecordingEnabled())
                .lastUpdated(camera.getUpdatedAt())
                .build();
    }
}
