package com.uocc.backend.service;

import com.uocc.backend.dto.request.IncidentCreateRequest;
import com.uocc.backend.dto.request.IncidentUpdateRequest;
import com.uocc.backend.dto.response.IncidentResponse;
import com.uocc.backend.entity.Incident;
import com.uocc.backend.exception.ResourceNotFoundException;
import com.uocc.backend.repository.IncidentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class IncidentService {

    private final IncidentRepository incidentRepository;

    @Transactional
    public IncidentResponse createIncident(IncidentCreateRequest request) {
        String status = request.getStatus() != null ? request.getStatus() : "active";

        Incident incident = Incident.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .status(status)
                .severity(request.getSeverity())
                .type(request.getType())
                .location(request.getLocation())
                .reportedAt(LocalDateTime.now())
                .assignedTo(request.getAssignedTo())
                .tags(request.getTags())
                .build();

        incident = incidentRepository.save(incident);
        return mapToResponse(incident);
    }

    public List<IncidentResponse> getAllIncidents(String status, String severity, String type,
                                                    Integer limit, Integer offset, String sort) {
        Specification<Incident> spec = Specification.where(null);

        if (status != null && !status.isEmpty()) {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("status"), status));
        }
        if (severity != null && !severity.isEmpty()) {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("severity"), severity));
        }
        if (type != null && !type.isEmpty()) {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("type"), type));
        }

        Sort sortOrder = Sort.by(Sort.Direction.DESC, "reportedAt");
        if (sort != null && !sort.isEmpty()) {
            String[] sortParams = sort.split(",");
            if (sortParams.length == 2) {
                Sort.Direction direction = sortParams[1].equalsIgnoreCase("asc") ? 
                        Sort.Direction.ASC : Sort.Direction.DESC;
                sortOrder = Sort.by(direction, sortParams[0]);
            }
        }

        int pageSize = (limit != null && limit > 0 && limit <= 100) ? limit : 20;
        int pageOffset = (offset != null && offset >= 0) ? offset : 0;
        Pageable pageable = PageRequest.of(pageOffset / pageSize, pageSize, sortOrder);

        Page<Incident> page = incidentRepository.findAll(spec, pageable);
        return page.getContent().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public IncidentResponse getIncidentById(Long id) {
        Incident incident = incidentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Incident not found with id: " + id));
        return mapToResponse(incident);
    }

    @Transactional
    public IncidentResponse updateIncident(Long id, IncidentUpdateRequest request) {
        Incident incident = incidentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Incident not found with id: " + id));

        if (request.getTitle() != null) incident.setTitle(request.getTitle());
        if (request.getDescription() != null) incident.setDescription(request.getDescription());
        if (request.getStatus() != null) incident.setStatus(request.getStatus());
        if (request.getSeverity() != null) incident.setSeverity(request.getSeverity());
        if (request.getType() != null) incident.setType(request.getType());
        if (request.getLocation() != null) incident.setLocation(request.getLocation());
        if (request.getResolvedAt() != null) incident.setResolvedAt(request.getResolvedAt());
        if (request.getAssignedTo() != null) incident.setAssignedTo(request.getAssignedTo());
        if (request.getTags() != null) incident.setTags(request.getTags());

        incident = incidentRepository.save(incident);
        return mapToResponse(incident);
    }

    @Transactional
    public void deleteIncident(Long id) {
        if (!incidentRepository.existsById(id)) {
            throw new ResourceNotFoundException("Incident not found with id: " + id);
        }
        incidentRepository.deleteById(id);
    }

    private IncidentResponse mapToResponse(Incident incident) {
        return IncidentResponse.builder()
                .id(incident.getId())
                .title(incident.getTitle())
                .description(incident.getDescription())
                .status(incident.getStatus())
                .severity(incident.getSeverity())
                .type(incident.getType())
                .location(incident.getLocation())
                .reportedAt(incident.getReportedAt())
                .resolvedAt(incident.getResolvedAt())
                .assignedTo(incident.getAssignedTo())
                .tags(incident.getTags())
                .build();
    }
}
