package com.uocc.backend.controller;

import com.uocc.backend.dto.request.SensorCreateRequest;
import com.uocc.backend.dto.request.SensorReadingCreateRequest;
import com.uocc.backend.dto.request.SensorUpdateRequest;
import com.uocc.backend.dto.response.SensorReadingResponse;
import com.uocc.backend.dto.response.SensorResponse;
import com.uocc.backend.service.SensorService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/sensors")
@RequiredArgsConstructor
@SecurityRequirement(name = "bearerAuth")
@Tag(name = "Sensors", description = "Sensor management endpoints")
public class SensorController {

    private final SensorService sensorService;

    @GetMapping
    @Operation(summary = "Get all sensors with filtering")
    public ResponseEntity<List<SensorResponse>> getAllSensors(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String type,
            @RequestParam(required = false) Integer limit,
            @RequestParam(required = false) Integer offset) {
        List<SensorResponse> sensors = sensorService.getAllSensors(status, type, limit, offset);
        return ResponseEntity.ok(sensors);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get sensor by ID")
    public ResponseEntity<SensorResponse> getSensorById(@PathVariable Long id) {
        SensorResponse sensor = sensorService.getSensorById(id);
        return ResponseEntity.ok(sensor);
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'OPERATOR')")
    @Operation(summary = "Create a new sensor")
    public ResponseEntity<SensorResponse> createSensor(@Valid @RequestBody SensorCreateRequest request) {
        SensorResponse sensor = sensorService.createSensor(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(sensor);
    }

    @PatchMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'OPERATOR')")
    @Operation(summary = "Update a sensor")
    public ResponseEntity<SensorResponse> updateSensor(
            @PathVariable Long id,
            @Valid @RequestBody SensorUpdateRequest request) {
        SensorResponse sensor = sensorService.updateSensor(id, request);
        return ResponseEntity.ok(sensor);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Delete a sensor (Admin only)")
    public ResponseEntity<Void> deleteSensor(@PathVariable Long id) {
        sensorService.deleteSensor(id);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/{sensorId}/readings")
    @Operation(summary = "Get sensor readings")
    public ResponseEntity<List<SensorReadingResponse>> getSensorReadings(
            @PathVariable Long sensorId,
            @RequestParam(required = false) Integer limit) {
        List<SensorReadingResponse> readings = sensorService.getSensorReadings(sensorId, limit);
        return ResponseEntity.ok(readings);
    }

    @PostMapping("/{sensorId}/readings")
    @PreAuthorize("hasAnyRole('ADMIN', 'OPERATOR')")
    @Operation(summary = "Add sensor reading")
    public ResponseEntity<SensorReadingResponse> addSensorReading(
            @PathVariable Long sensorId,
            @Valid @RequestBody SensorReadingCreateRequest request) {
        SensorReadingResponse reading = sensorService.addSensorReading(sensorId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(reading);
    }
}
