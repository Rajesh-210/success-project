package com.uocc.backend.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DashboardStatsResponse {
    private long activeIncidents;
    private long onlineSensors;
    private long onlineCameras;
    private double systemHealthPercent;
    private double avgResponseTimeMinutes;
    private double resolutionRatePercent;
    private double performanceScore;
}
