package com.uocc.backend.dto.request;

import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CameraUpdateRequest {

    private String name;

    private JsonNode location;

    @Pattern(regexp = "^(online|offline|maintenance)$", message = "Status must be online, offline, or maintenance")
    private String status;

    private String streamUrl;
    
    private String lastSnapshot;
    
    private Boolean recordingEnabled;
}
