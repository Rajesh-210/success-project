package com.uocc.backend.controller;

import com.uocc.backend.dto.request.UserUpdateRequest;
import com.uocc.backend.dto.response.UserResponse;
import com.uocc.backend.service.AuthService;
import com.uocc.backend.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
@Tag(name = "Users", description = "User management endpoints")
public class UserController {

    private final UserService userService;
    private final AuthService authService;

    @GetMapping("/me")
    @Operation(summary = "Get current authenticated user")
    public ResponseEntity<UserResponse> me() {
        return ResponseEntity.ok(authService.getCurrentUser());
    }

    @PatchMapping("/me")
    @Operation(summary = "Update current authenticated user profile")
    public ResponseEntity<UserResponse> updateMe(@Valid @RequestBody UserUpdateRequest request) {
        UserResponse current = authService.getCurrentUser();
        return ResponseEntity.ok(userService.updateUser(current.getId(), request));
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "List users with pagination")
    public ResponseEntity<List<UserResponse>> list(
            @RequestParam(required = false) @Parameter(description = "Results per page (max 100)") Integer limit,
            @RequestParam(required = false) @Parameter(description = "Results offset") Integer offset
    ) {
        return ResponseEntity.ok(userService.getAllUsers(limit, offset));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Get user by id")
    public ResponseEntity<UserResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(userService.getUserById(id));
    }

    @PatchMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Update user")
    public ResponseEntity<UserResponse> update(
            @PathVariable Long id,
            @Valid @RequestBody UserUpdateRequest request
    ) {
        return ResponseEntity.ok(userService.updateUser(id, request));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Delete user")
    public ResponseEntity<com.uocc.backend.dto.response.ApiResponse<java.util.Map<String, String>>> delete(@PathVariable Long id) {
        var deleted = userService.deleteUser(id);
        java.util.Map<String, String> data = new java.util.HashMap<>();
        data.put("username", deleted.getEmail());
        return ResponseEntity.ok(com.uocc.backend.dto.response.ApiResponse.ok("User deleted", data));
    }
}
