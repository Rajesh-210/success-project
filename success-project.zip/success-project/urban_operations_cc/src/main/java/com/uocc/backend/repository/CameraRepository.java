package com.uocc.backend.repository;

import com.uocc.backend.entity.Camera;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface CameraRepository extends JpaRepository<Camera, Long>, JpaSpecificationExecutor<Camera> {
    
    @Query("SELECT COUNT(c) FROM Camera c WHERE c.status = 'online'")
    long countOnlineCameras();
}
