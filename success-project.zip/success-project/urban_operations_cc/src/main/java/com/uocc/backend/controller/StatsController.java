package com.uocc.backend.controller;

import com.uocc.backend.dto.response.CountResponse;
import com.uocc.backend.dto.response.DashboardStatsResponse;
import com.uocc.backend.dto.response.IncidentSeverityCount;
import com.uocc.backend.dto.response.IncidentTypeCount;
import com.uocc.backend.dto.response.ResponseTimeByDay;
import com.uocc.backend.dto.response.TimeSeriesPoint;
import com.uocc.backend.service.StatsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@SecurityRequirement(name = "bearerAuth")
@Tag(name = "Statistics", description = "Statistics and analytics endpoints")
public class StatsController {

    private final StatsService statsService;

    @GetMapping("/stats/active-incidents-count")
    @Operation(summary = "Get count of active incidents")
    public ResponseEntity<CountResponse> getActiveIncidentsCount() {
        return ResponseEntity.ok(statsService.getActiveIncidentsCount());
    }

    @GetMapping("/stats/online-sensors-count")
    @Operation(summary = "Get count of online sensors")
    public ResponseEntity<CountResponse> getOnlineSensorsCount() {
        return ResponseEntity.ok(statsService.getOnlineSensorsCount());
    }

    @GetMapping("/stats/online-cameras-count")
    @Operation(summary = "Get count of online cameras")
    public ResponseEntity<CountResponse> getOnlineCamerasCount() {
        return ResponseEntity.ok(statsService.getOnlineCamerasCount());
    }

    @GetMapping("/stats/dashboard")
    @Operation(summary = "Get combined dashboard statistics")
    public ResponseEntity<DashboardStatsResponse> getDashboardStats() {
        return ResponseEntity.ok(statsService.getDashboardStats());
    }

    @GetMapping("/analytics/incidents-by-type")
    @Operation(summary = "Get incidents grouped by type")
    public ResponseEntity<List<IncidentTypeCount>> getIncidentsByType() {
        return ResponseEntity.ok(statsService.getIncidentsByType());
    }

    @GetMapping("/analytics/incidents-by-severity")
    @Operation(summary = "Get incidents grouped by severity")
    public ResponseEntity<List<IncidentSeverityCount>> getIncidentsBySeverity() {
        return ResponseEntity.ok(statsService.getIncidentsBySeverity());
    }

    @GetMapping("/analytics/incident-volume-24h")
    @Operation(summary = "Get incident volume for the last 24 hours")
    public ResponseEntity<List<TimeSeriesPoint>> getIncidentVolume24h() {
        return ResponseEntity.ok(statsService.getIncidentVolumeLast24Hours());
    }

    @GetMapping("/analytics/sensor-alerts-24h")
    @Operation(summary = "Get sensor alerts volume for the last 24 hours")
    public ResponseEntity<List<TimeSeriesPoint>> getSensorAlerts24h() {
        return ResponseEntity.ok(statsService.getSensorAlertsLast24Hours());
    }

    @GetMapping("/analytics/response-time-by-day")
    @Operation(summary = "Get average response time by day over the last 7 days")
    public ResponseEntity<List<ResponseTimeByDay>> getResponseTimeByDay() {
        return ResponseEntity.ok(statsService.getResponseTimeByDayLast7Days());
    }
}
