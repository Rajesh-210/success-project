import { useEffect, useState } from 'react';
import { AppShell } from '@/components/AppShell';
import { TimeSeriesChart } from '@/components/TimeSeriesChart';
import { KPICard } from '@/components/KPICard';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import { Activity, TrendingUp, AlertCircle, CheckCircle } from 'lucide-react';
import api from '@/api/axiosClient';
import apiEndpoints from '@/api/apiEndpoints';

export default function Analytics() {
  const [activeAlertsCount, setActiveAlertsCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [incidentsByType, setIncidentsByType] = useState([]);
  const [incidentsBySeverity, setIncidentsBySeverity] = useState([]);
  const [incidentVolume, setIncidentVolume] = useState([]);
  const [sensorAlerts, setSensorAlerts] = useState([]);
  const [responseTimeByDay, setResponseTimeByDay] = useState([]);
  const [avgResponseTime, setAvgResponseTime] = useState('0 min');
  const [resolutionRate, setResolutionRate] = useState('0%');
  const [performanceScore, setPerformanceScore] = useState('0/10');

  useEffect(() => {
    loadAnalyticsData();
  }, []);

  const loadAnalyticsData = async () => {
    try {
      const incidentsUrl = apiEndpoints.incidents?.getAllIncidentsGET || '/api/incidents';
      const byTypeUrl =
        apiEndpoints.analytics?.getIncidentsByTypeGET ||
        '/api/analytics/incidents-by-type';
      const bySeverityUrl =
        apiEndpoints.analytics?.getIncidentsBySeverityGET ||
        '/api/analytics/incidents-by-severity';
      const incidentVolumeUrl =
        apiEndpoints.analytics?.getIncidentVolume24hGET ||
        '/api/analytics/incident-volume-24h';
      const sensorAlertsUrl =
        apiEndpoints.analytics?.getSensorAlerts24hGET ||
        '/api/analytics/sensor-alerts-24h';
      const responseTimeUrl =
        apiEndpoints.analytics?.getResponseTimeByDayGET ||
        '/api/analytics/response-time-by-day';
      const dashboardUrl =
        apiEndpoints.statistics?.getDashboardStatsGET || '/api/stats/dashboard';

      const [incRes, typeRes, sevRes, volumeRes, alertsRes, respRes, dashRes] =
        await Promise.all([
          api.get(incidentsUrl), // incidents can change often; no caching
          api.getCached(byTypeUrl),
          api.getCached(bySeverityUrl),
          api.getCached(incidentVolumeUrl),
          api.getCached(sensorAlertsUrl),
          api.getCached(responseTimeUrl),
          api.getCached(dashboardUrl),
        ]);

      const incidentsPayload = Array.isArray(incRes.data?.data)
        ? incRes.data.data
        : Array.isArray(incRes.data)
          ? incRes.data
          : [];

      // KPIs from dashboard stats
      const dash = dashRes.data?.data || dashRes.data || {};
      setAvgResponseTime(
        typeof dash.avgResponseTimeMinutes === 'number'
          ? `${dash.avgResponseTimeMinutes} min`
          : '0 min'
      );
      setResolutionRate(
        typeof dash.resolutionRatePercent === 'number'
          ? `${dash.resolutionRatePercent.toFixed(2)}%`
          : '0%'
      );
      setPerformanceScore(
        typeof dash.performanceScore === 'number'
          ? `${dash.performanceScore.toFixed(2)}/10`
          : '0/10'
      );

      // Active alerts = high + critical incidents
      const incidents = incidentsPayload;
      const activeAlerts = incidents.filter((inc) => {
        const sev = (inc.severity || '').toLowerCase();
        return sev === 'critical' || sev === 'high';
      }).length;
      setActiveAlertsCount(activeAlerts);

      // Incidents by type
      const typeRaw = typeRes.data?.data ?? typeRes.data ?? [];
      let typeSeries = [];
      if (Array.isArray(typeRaw)) {
        typeSeries = typeRaw.map((item, idx) => ({
          type: item.type || item.name || item.label || `Type ${idx + 1}`,
          count:
            typeof item.count === 'number'
              ? item.count
              : typeof item.value === 'number'
                ? item.value
                : typeof item.total === 'number'
                  ? item.total
                  : 0,
        }));
      } else if (typeRaw && typeof typeRaw === 'object') {
        typeSeries = Object.entries(typeRaw).map(([key, value]) => ({
          type: key,
          count:
            typeof value === 'number'
              ? value
              : typeof value?.count === 'number'
                ? value.count
                : 0,
        }));
      }
      setIncidentsByType(typeSeries);

      // Incidents by severity
      const sevRaw = sevRes.data?.data ?? sevRes.data ?? [];
      let sevSeries = [];
      if (Array.isArray(sevRaw)) {
        sevSeries = sevRaw.map((item, idx) => ({
          name: item.severity || item.name || item.label || `Bucket ${idx + 1}`,
          value:
            typeof item.count === 'number'
              ? item.count
              : typeof item.value === 'number'
                ? item.value
                : typeof item.total === 'number'
                  ? item.total
                  : 0,
        }));
      } else if (sevRaw && typeof sevRaw === 'object') {
        sevSeries = Object.entries(sevRaw).map(([key, value]) => ({
          name: key,
          value:
            typeof value === 'number'
              ? value
              : typeof value?.count === 'number'
                ? value.count
                : 0,
        }));
      }
      // Assign colors deterministically
      const palette = ['#ef4444', '#f97316', '#eab308', '#3b82f6', '#22c55e'];
      sevSeries = sevSeries.map((entry, idx) => ({
        ...entry,
        color: palette[idx % palette.length],
      }));
      setIncidentsBySeverity(sevSeries);

      // Time series: incident volume & sensor alerts
      const volumePayload = Array.isArray(volumeRes.data?.data)
        ? volumeRes.data.data
        : Array.isArray(volumeRes.data)
          ? volumeRes.data
          : [];
      setIncidentVolume(volumePayload);

      const alertsPayload = Array.isArray(alertsRes.data?.data)
        ? alertsRes.data.data
        : Array.isArray(alertsRes.data)
          ? alertsRes.data
          : [];
      setSensorAlerts(alertsPayload);

      // Response time by day
      const respPayload = Array.isArray(respRes.data?.data)
        ? respRes.data.data
        : Array.isArray(respRes.data)
          ? respRes.data
          : [];
      const respSeries = respPayload.map((item) => ({
        day: item.day,
        avgTime: item.avgTimeMinutes,
      }));
      setResponseTimeByDay(respSeries);
    } catch (error) {
      console.error('Error loading analytics data:', error);
    } finally {
      setLoading(false);
    }
  };


  return (
    <AppShell>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Analytics</h1>
          <p className="text-muted-foreground mt-1">
            Insights and trends for city operations
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <KPICard
            label="Avg Response Time"
            value={avgResponseTime}
            change={0}
            trend="neutral"
            icon={<Activity className="h-5 w-5" />}
          />
          <KPICard
            label="Resolution Rate"
            value={resolutionRate}
            change={0}
            trend="neutral"
            icon={<CheckCircle className="h-5 w-5" />}
          />
          <KPICard
            label="Active Alerts"
            value={activeAlertsCount}
            change={0}
            trend="neutral"
            icon={<AlertCircle className="h-5 w-5" />}
          />
          <KPICard
            label="Performance Score"
            value={performanceScore}
            change={0}
            trend="neutral"
            icon={<TrendingUp className="h-5 w-5" />}
          />
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <TimeSeriesChart
            title="Incident Volume (24h)"
            data={incidentVolume}
            color="#ef4444"
            yAxisLabel="Incidents"
          />
          <TimeSeriesChart
            title="Sensor Alerts (24h)"
            data={sensorAlerts}
            color="#f97316"
            yAxisLabel="Alerts"
          />
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Incidents by Type</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="w-full overflow-x-auto">
                <div className="min-w-[400px] lg:min-w-0">
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={incidentsByType}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="type" angle={-45} textAnchor="end" height={100} />
                  <YAxis />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--popover))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '6px',
                    }}
                  />
                  <Bar dataKey="count" fill="#3b82f6" />
                </BarChart>
              </ResponsiveContainer>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Incidents by Severity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="w-full overflow-x-auto">
                <div className="min-w-[400px] lg:min-w-0">
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                  <Pie
                    data={incidentsBySeverity}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) =>
                      `${name}: ${(percent * 100).toFixed(0)}%`
                    }
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {incidentsBySeverity.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Average Response Time by Day</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="w-full overflow-x-auto">
              <div className="min-w-[400px] lg:min-w-0">
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={responseTimeByDay}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="day" />
                <YAxis label={{ value: 'Minutes', angle: -90, position: 'insideLeft' }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'hsl(var(--popover))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '6px',
                  }}
                />
                <Bar dataKey="avgTime" fill="#10b981" />
              </BarChart>
            </ResponsiveContainer>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Power BI Embedded Dashboard</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="aspect-video bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-800 dark:to-slate-900 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <Activity className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">
                  Power BI Dashboard Integration
                </p>
                <p className="text-sm text-muted-foreground mt-2">
                  Configure VITE_PUBLIC_POWERBI_KEY in environment
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}

