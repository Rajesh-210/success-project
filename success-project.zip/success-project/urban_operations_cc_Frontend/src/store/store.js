import { configureStore } from '@reduxjs/toolkit';
import authReducer from '../features/auth/authSlice';
import { storeRef } from './storeRef';

export const store = configureStore({
  reducer: {
    auth: authReducer
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false
    })
});

storeRef.setStore(store);

export default store;
