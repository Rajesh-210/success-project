import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import ErrorBoundary from './components/ErrorBoundary';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Incidents from './pages/Incidents';
import IncidentDetail from './pages/IncidentDetail';
import Alerts from './pages/Alerts';
import Sensors from './pages/Sensors';
import Map from './pages/Map';
import CCTV from './pages/CCTV';
import Analytics from './pages/Analytics';
import Settings from './pages/Settings';

function PrivateRoute({ children, roles }) {
  const { isAuthenticated, user } = useSelector((state) => state.auth);
  const token = localStorage.getItem(import.meta.env.VITE_JWT_STORAGE_KEY || 'auth_token');
  const authed = isAuthenticated || !!token;

  if (!authed) {
    return <Navigate to="/login" replace />;
  }

  if (roles && roles.length > 0) {
    const userRole = user?.role;

    // If authenticated but user profile not yet loaded, allow access for now.
    // Backend will still enforce permissions and 401 will trigger logout.
    if (userRole && !roles.includes(userRole)) {
      // Logged in but not allowed for this route; send to dashboard
      return <Navigate to="/dashboard" replace />;
    }
  }

  return children;
}

function App() {
  return (
    <ErrorBoundary>
      <Router>
        <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route
          path="/dashboard"
          element={
            <PrivateRoute roles={['admin', 'operator', 'viewer']}>
              <Dashboard />
            </PrivateRoute>
          }
        />
        <Route
          path="/incidents"
          element={
            <PrivateRoute roles={['admin', 'operator']}>
              <Incidents />
            </PrivateRoute>
          }
        />
        <Route
          path="/incidents/:id"
          element={
            <PrivateRoute roles={['admin', 'operator']}>
              <IncidentDetail />
            </PrivateRoute>
          }
        />
        <Route
          path="/alerts"
          element={
            <PrivateRoute roles={['admin', 'operator']}>
              <Alerts />
            </PrivateRoute>
          }
        />
        <Route
          path="/sensors"
          element={
            <PrivateRoute roles={['admin', 'operator']}>
              <Sensors />
            </PrivateRoute>
          }
        />
        <Route
          path="/map"
          element={
            <PrivateRoute roles={['admin', 'operator', 'viewer']}>
              <Map />
            </PrivateRoute>
          }
        />
        <Route
          path="/cctv"
          element={
            <PrivateRoute roles={['admin', 'operator']}>
              <CCTV />
            </PrivateRoute>
          }
        />
        <Route
          path="/analytics"
          element={
            <PrivateRoute roles={['admin']}>
              <Analytics />
            </PrivateRoute>
          }
        />
        <Route
          path="/settings"
          element={
            <PrivateRoute roles={['admin']}>
              <Settings />
            </PrivateRoute>
          }
        />
        {/* First page is login when not logged in; any unknown path also goes to login */}
        <Route path="/" element={<Navigate to="/login" replace />} />
        <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </Router>
    </ErrorBoundary>
  );
}

export default App;

