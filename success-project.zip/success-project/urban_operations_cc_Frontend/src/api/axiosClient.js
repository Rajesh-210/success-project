import axios from 'axios';
import { storeRef } from '../store/storeRef';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL,
  withCredentials: false
});

// Simple in-memory cache for GET responses to reduce duplicate API calls
const responseCache = new Map();
const DEFAULT_TTL = 30_000; // 30 seconds

function buildCacheKey(url, config = {}) {
  const params = config.params ? JSON.stringify(config.params) : '';
  return `${url}?${params}`;
}

api.getCached = async function (url, config = {}, ttl = DEFAULT_TTL) {
  const key = buildCacheKey(url, config);
  const now = Date.now();
  const cached = responseCache.get(key);

  if (cached && now - cached.timestamp < ttl) {
    return cached.response;
  }

  const response = await api.get(url, config);
  responseCache.set(key, { timestamp: now, response });
  return response;
};

// Invalidate cached GET responses, optionally by URL prefix
api.invalidateCache = function (prefix) {
  if (!prefix) {
    responseCache.clear();
    return;
  }
  for (const key of responseCache.keys()) {
    if (key.startsWith(prefix)) {
      responseCache.delete(key);
    }
  }
};

function parseJwt(token) {
  try {
    const [, payload] = token.split('.');
    if (!payload) return null;
    const base64 = payload.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split('')
        .map(c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
        .join('')
    );
    return JSON.parse(jsonPayload);
  } catch {
    return null;
  }
}

function isTokenExpired(token) {
  const payload = parseJwt(token);
  if (!payload || !payload.exp) return false;
  const expiryMs = payload.exp * 1000;
  return Date.now() >= expiryMs;
}

function getToken() {
  const key = import.meta.env.VITE_JWT_STORAGE_KEY || 'auth_token';
  let token;
  try {
    token = storeRef.getState()?.auth?.token || localStorage.getItem(key);
  } catch {
    token = localStorage.getItem(key);
  }

  if (!token) return null;

  if (isTokenExpired(token)) {
    try {
      import('../features/auth/authSlice').then(({ logout, setSessionExpired }) => {
        storeRef.dispatch(setSessionExpired(true));
        storeRef.dispatch(logout());
      });
    } catch {}
    localStorage.removeItem(key);
    return null;
  }

  return token;
}

api.interceptors.request.use(
  config => {
    const token = getToken();
    if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
  },
  error => Promise.reject(error)
);

api.interceptors.response.use(
  res => res,
  error => {
    const status = error?.response?.status;
    const message =
      error?.response?.data?.message ||
      error?.response?.data?.error ||
      error?.message ||
      'Request failed';

    if (status === 401) {
      try {
        // Dynamically import logout to avoid circular dependency
        import('../features/auth/authSlice').then(({ logout }) => {
          storeRef.dispatch(logout());
        });
      } catch {}
    }

    return Promise.reject({ ...error, message });
  }
);

export default api;
