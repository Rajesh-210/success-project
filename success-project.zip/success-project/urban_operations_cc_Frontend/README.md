# AI Urban Ops Frontend (Urban Operations Control Center)

A React + Vite single-page application for a smart city command & control center.  
It connects to a Spring Boot backend and provides real‑time views of incidents, sensors, cameras, alerts, analytics, and maps.

---

## Features

### Authentication & Roles

- JWT-based login and registration.
- Role-based access:
  - **admin** – full access (Dashboard, Map, Incidents, Alerts, Sensors, CCTV, Analytics, Settings).
  - **operator** – operational views (Dashboard, Map, Incidents, Alerts, Sensors, CCTV).
  - **viewer** – read-only overviews (Dashboard, Map).
- All protected routes are only accessible after login.
- Session handling:
  - JWT expiration time: **60 minutes** (from `exp` claim).
  - After expiry, user is automatically logged out on the next request.
  - Login page shows a clear “**Your session has expired. Please sign in again.**” message.

### Dashboard

- Real‑time overview of city operations:
  - Active incidents, online sensors, online cameras.
  - System health percent.
- Time‑series charts (24h):
  - Incident volume.
  - Sensor alert activity.
- Recent incidents table with quick navigation to incident detail.

### Incidents & Alerts

- **Incidents page**:
  - List incidents with status tabs: All, Active, Investigating, Resolved, Closed.
  - Search by title/description/type.
  - Create, edit, delete incidents.
  - Click row to view incident detail.
- **Incident detail**:
  - Full incident information, timeline, and location.
  - Status updates (e.g., Active → Resolved).
- **Alerts page**:
  - Alerts derived from incidents (e.g., high/critical severity).
  - Filter by priority (Critical, High, Medium, Low).
  - Search by title/message.
  - Create/edit alerts (backed by incident endpoints).
  - Delete alerts (deletes underlying incident).

### Sensors

- Sensor inventory and status monitoring:
  - Tabs for types (All, Air Quality, Traffic, Noise, Water, Weather).
  - Displays ID, type, status, value, last updated.
- Create/edit sensors:
  - Type, status, numeric value.
  - Backend payload includes `lastReading` with timestamp.
- Delete sensors with confirmation.

### CCTV / Cameras

- List and monitor cameras:
  - Grid view: cards with video player and location details.
  - Table view: ID, name, location, status, last updated.
- Create/edit cameras:
  - Name, location, status, stream URL, recording flag.
- Delete cameras with confirmation.

### Map View

- Real‑time geospatial view of:
  - Incidents (red dots).
  - Sensors (yellow dots).
  - Cameras (green dots).
- Tabs:
  - **All** – shows all incidents, sensors, cameras at once.
  - **Incidents** – only incident dots.
  - **Sensors** – only sensor dots.
  - **Cameras** – only camera dots.
- Map behavior:
  - Loads data once using backend endpoints for `/api/incidents`, `/api/sensors`, `/api/cameras`.
  - Computes center based on visible items for the current tab.
  - Colored marker icons with popups (title, description, type, status).

### Analytics

- KPIs:
  - Average response time.
  - Resolution rate.
  - Active alerts (based on incident severity).
  - Performance score.
- Charts:
  - Incident volume (24h).
  - Sensor alerts (24h).
  - Incidents by type and by severity.
  - Average response time by day.
- All analytics use backend `/api/analytics/*` and `/api/stats/dashboard`.

### Settings

- **Profile**:
  - View current user profile from `/api/users/me`.
  - Update email via `PATCH /api/users/me`.
- **Notifications**:
  - UI-only toggles for email, push, and critical alerts.
- **Appearance**:
  - Light / Dark / System theme.
  - Map style selector (UI-only).
- **Security**:
  - Change password via `/api/auth/change-password`.
- **Integrations**:
  - Shows backend connection status (no URL exposure).

---

## Tech Stack

- **Framework**: React 18, Vite
- **State Management**: Redux Toolkit
- **Routing**: React Router
- **HTTP**: Axios (custom client with interceptors)
- **UI**:
  - Tailwind CSS
  - shadcn/ui style components (Cards, Tabs, Tables, Buttons, Dialogs, etc.)
  - Lucide icons
- **Maps**: React-Leaflet + Leaflet (OpenStreetMap tiles)
- **Charts**: Recharts

---

## Prerequisites

- **Node.js**: v18+ recommended
- **npm**: v9+ (or yarn/pnpm if you prefer, adjust commands accordingly)
- **Backend**:
  - Spring Boot backend running and accessible via `VITE_API_BASE_URL` (commonly `http://localhost:8080`).
  - Backend endpoints implemented as described in `reqirement.txt`.

---

## Getting Started

### 1. Clone the repository

```bash
git clone <your-backend-repo-or-monorepo-url>
cd Frontend
```

> Adjust `Frontend` to the actual folder name if different (this project lives in `HackthonOld/Frontend` on your machine).

### 2. Install dependencies

```bash
npm install
```

### 3. Environment configuration

Create a `.env` file in the project root:

```bash
cp .env.example .env  # if an example is present
```

If there is no `.env.example`, create `.env` manually with at least:

```bash
VITE_API_BASE_URL=http://localhost:8080
VITE_JWT_STORAGE_KEY=auth_token
```

Optional (if you wire Power BI or other integrations later):

```bash
VITE_PUBLIC_POWERBI_KEY=<your_power_bi_key>
```

**Notes:**

- `VITE_API_BASE_URL` must match your backend base URL.
- `VITE_JWT_STORAGE_KEY` is the key used in `localStorage` to store JWT tokens.

### 4. Run the development server

```bash
npm run dev
```

By default Vite serves on `http://localhost:5173`.

---

## Available Scripts

In the project directory, you can run:

```bash
npm run dev
```

- Starts the dev server with hot reload.

```bash
npm run build
```

- Builds the app for production into the `dist` folder.

```bash
npm run preview
```

- Serves the built `dist` folder locally (useful to test production build).

(If there are additional scripts like `lint` or `test`, add them here based on `package.json`.)

---

## Project Structure (high-level)

- `src/`
  - `App.jsx` – Router and route protection (`PrivateRoute`).
  - `main.jsx` – App entry point, Redux provider.
  - `index.css` – Tailwind & global styles (includes Leaflet CSS).
  - `api/`
    - `axiosClient.js` – Axios instance, JWT interceptors, response caching.
    - `apiEndpoints.js` – Generated mapping of backend endpoints.
  - `features/auth/`
    - `authSlice.js` – Authentication state, thunks (login, register, fetchProfile), JWT handling.
  - `pages/`
    - `Login.jsx`, `Register.jsx`
    - `Dashboard.jsx`
    - `Incidents.jsx`, `IncidentDetail.jsx`
    - `Alerts.jsx`
    - `Sensors.jsx`
    - `CCTV.jsx`
    - `Map.jsx`
    - `Analytics.jsx`
    - `Settings.jsx`
  - `components/`
    - `AppShell.jsx` – Main layout with sidebar, header, content.
    - `Sidebar.jsx`, `KPICard.jsx`, `TimeSeriesChart.jsx`, etc.
    - `IncidentDialog.jsx`, `SensorDialog.jsx`, `CameraDialog.jsx`, `AlertDialog.jsx`
    - `CityMap.jsx` – Leaflet map wrapper with colored markers.
    - Various shadcn-style UI primitives.

---

## Authentication & Session Handling

- **JWT storage**:
  - Tokens are stored in `localStorage` under the key `VITE_JWT_STORAGE_KEY` (default: `auth_token`).
- **Token injection**:
  - `axiosClient` attaches `Authorization: Bearer <token>` to requests when a valid token exists.
- **Expiration**:
  - On app load, any expired token (based on JWT `exp`) is cleared.
  - Before each request, if token is expired:
    - Redux `logout()` is dispatched.
    - `sessionExpired` flag is set.
    - Token is removed from `localStorage`.
  - The next navigation to `/login` shows a “session expired” banner.

---

## API Contract

The expected backend contract is documented in `reqirement.txt`:

- Auth endpoints:
  - `POST /api/auth/register`
  - `POST /api/auth/login`
  - `GET /api/users/me`
  - `PATCH /api/users/me`
  - `POST /api/auth/change-password`
- Incidents:
  - `GET /api/incidents`
  - `GET /api/incidents/{id}`
  - `POST /api/incidents`
  - `PATCH /api/incidents/{id}`
  - `DELETE /api/incidents/{id}`
- Sensors:
  - `GET /api/sensors`
  - `GET /api/sensors/{id}`
  - `POST /api/sensors`
  - `PATCH /api/sensors/{id}`
  - `DELETE /api/sensors/{id}`
- Cameras:
  - `GET /api/cameras`
  - `GET /api/cameras/{id}`
  - `POST /api/cameras`
  - `PATCH /api/cameras/{id}`
  - `DELETE /api/cameras/{id}`
- Stats & Analytics:
  - `GET /api/stats/dashboard`
  - `GET /api/analytics/incidents-by-type`
  - `GET /api/analytics/incidents-by-severity`
  - `GET /api/analytics/incident-volume-24h`
  - `GET /api/analytics/sensor-alerts-24h`
  - `GET /api/analytics/response-time-by-day`

The frontend is designed to work with the **wrapper response format**:

```json
{
  "success": true,
  "message": "OK",
  "data": []
}
```

but also gracefully handles legacy responses where the array/object is at the root.

---

## Caching & Performance

- `axiosClient` implements a simple in-memory cache for **GET** requests:
  - `api.getCached(url, config?, ttl?)` returns cached responses for a short TTL (default 30s).
  - Used for dashboard stats, analytics, and shared lists (incidents, sensors, cameras) to reduce duplicate calls.
- On mutating operations (create/edit/delete incidents/sensors/cameras), the app invalidates relevant cache prefixes:
  - `/api/incidents`
  - `/api/sensors`
  - `/api/cameras`
  - `/api/stats/dashboard`
  - `/api/analytics`

This keeps the UI responsive while avoiding unnecessary backend load.

---

## Map View Details

- Backend must provide `location` for incidents, sensors, and cameras.
- Accepted shapes per location:

```json
{ "lat": 23.1, "lng": 72.5 }
```

or:

```json
{ "latitude": 23.1, "longitude": 72.5 }
```

- The Map page normalizes both forms and converts any string coordinates to numbers.
- Markers:
  - Incidents → red circle.
  - Sensors → yellow circle.
  - Cameras → green circle.
- Tabs control what’s displayed and how the map is centered.

---

## Development Notes

- When adding new pages or endpoints:
  - Add endpoint definitions to `src/api/apiEndpoints.js` (if using generated mapping).
  - Use `axiosClient` for API calls to get auth, error handling, and caching.
- When updating the backend contract:
  - Keep `reqirement.txt` in sync.
  - Adjust normalization logic in pages/components rather than spreading ad hoc parsing.

---

If you want, we can also add a shorter "Quick Start" section or a separate `CONTRIBUTING.md` with coding style and PR guidelines.
